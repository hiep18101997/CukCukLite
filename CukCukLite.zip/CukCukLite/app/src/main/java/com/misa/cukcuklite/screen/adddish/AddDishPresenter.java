package com.misa.cukcuklite.screen.adddish;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.IOException;
import java.io.InputStream;

public class AddDishPresenter implements IAddDishContract.IPresenter {
    private static final String TAG = AddDishPresenter.class.getName();

    private IAddDishContract.IView mView;

    public AddDishPresenter(IAddDishContract.IView view) {
        mView = view;
    }

    @Override
    public Bitmap getBitmapFromAssets(Context context, String icon) {
        AssetManager assetManager = context.getAssets();
        InputStream istr = null;
        try {
            istr = assetManager.open("images/" + icon);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return BitmapFactory.decodeStream(istr);
    }
}
