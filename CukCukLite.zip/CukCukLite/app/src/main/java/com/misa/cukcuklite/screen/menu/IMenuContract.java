package com.misa.cukcuklite.screen.menu;

interface IMenuContract {
    interface IView {
    }

    interface IPresenter {
        void getAllDish();
    }
}
