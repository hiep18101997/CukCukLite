package com.misa.cukcuklite.data.db;

import androidx.room.Room;
import android.content.Context;
 /**
 ‐ Mục đích Class : tạo ra đối tượng tương tác với database
 *
 ‐ @created_by dhhiep on 3/22/2019
 */
public class DatabaseClient {
    private static DatabaseClient mInstance;
    private Context mCtx;
    private AppDatabase appDatabase;

    private DatabaseClient(Context mCtx) {
        this.mCtx = mCtx;
        appDatabase = Room.databaseBuilder(mCtx, AppDatabase.class, "MyToDos").build();
    }

    public static synchronized DatabaseClient getInstance(Context mCtx) {
        if (mInstance == null) {
            mInstance = new DatabaseClient(mCtx);
        }
        return mInstance;
    }

    public AppDatabase getAppDatabase() {
        return appDatabase;
    }
}