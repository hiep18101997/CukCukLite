package com.misa.cukcuklite.screen.chooseunit;

public class ChooseUnitPresenter implements IChooseUnitContract.IPresenter {
    private static final String TAG = ChooseUnitPresenter.class.getName();

    private IChooseUnitContract.IView mView;

    public ChooseUnitPresenter(IChooseUnitContract.IView view) {
        mView = view;
    }
}
