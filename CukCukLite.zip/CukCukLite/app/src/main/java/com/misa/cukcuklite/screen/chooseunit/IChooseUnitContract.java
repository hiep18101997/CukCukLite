package com.misa.cukcuklite.screen.chooseunit;

interface IChooseUnitContract {
    interface IView {
    }

    interface IPresenter {
    }
}
