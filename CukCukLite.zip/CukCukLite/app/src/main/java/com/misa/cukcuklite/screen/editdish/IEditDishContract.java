package com.misa.cukcuklite.screen.editdish;

interface IEditDishContract {
    interface IView {
    }

    interface IPresenter {
    }
}
