package com.misa.cukcuklite.data.db;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.misa.cukcuklite.data.db.model.Dish;

/**
 * ‐ Mục đích Class : ra lớp để kế thừa lại Roomdatabase
 * <p>
 * ‐ @created_by dhhiep on 3/22/2019
 */
@Database(entities = {Dish.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract DishDAO mUserDAO();
}
