package com.misa.cukcuklite.screen.chooseunit;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.misa.cukcuklite.R;
import com.misa.cukcuklite.data.db.model.Unit;
import com.misa.cukcuklite.screen.adddish.AddDishActivity;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ChooseUnitActivity extends AppCompatActivity implements IChooseUnitContract.IView {
    private static final String TAG = ChooseUnitActivity.class.getName();
    private IChooseUnitContract.IPresenter mPresenter;
    private ChooseUnitAdapter mAdapter;

    public static Intent getIntent(Context context) {
        Intent intent = new Intent(context, ChooseUnitActivity.class);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_unit);
        mPresenter = new ChooseUnitPresenter(this);
        initComponent();
    }

    private void initComponent() {
        mAdapter=new ChooseUnitAdapter(getListFake(),this);
        RecyclerView recyclerView=findViewById(R.id.rvUnit);
        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private ArrayList<Unit> getListFake() {
        ArrayList<Unit> list=new ArrayList<>();
        list.add(new Unit("Cái"));
        list.add(new Unit("Lon"));
        list.add(new Unit("Chai"));
        list.add(new Unit("Miếng"));
        list.add(new Unit("Shot"));
        list.add(new Unit("Turn"));
        list.add(new Unit("Đĩa"));
        list.add(new Unit("Điếu"));
        list.add(new Unit("Cốc"));
        return list;
    }
}
